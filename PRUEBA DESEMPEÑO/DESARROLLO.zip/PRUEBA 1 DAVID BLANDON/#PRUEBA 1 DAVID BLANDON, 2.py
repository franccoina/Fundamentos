#app para desc

factura = {}
descOperaciones = [0,0.95,0.9,0.85]
desc = [0,5,10,15]
flag = 0

def compra():
    if flag == 0:
        monto = int(input(f'''
CALCULADORA DE COMPRA:

BIENVENIDO, a nuestro sistema de calculadora para su compra. Por favor ingrese
el monto total de su compra, y le mostraremos su factura

MONTO TOTAL:'''))
        
        if monto <= 100:
            montoDesc = monto
            factura = {'Valor a pagar':monto}
            print(f'''
FACTURA DE COMPRA:

Teniendo en cuenta que su monto total por la compra fue de''',monto,''',
y que los descuentos aplicados fueron por''',desc[0],'''%, su factura es
la siguiente:

''',factura)
        
        if monto >= 100 and monto<=500:
            montoDesc = monto * descOperaciones[1]
            factura = {'Valor a pagar':montoDesc}
            print(f'''
FACTURA DE COMPRA:

Teniendo en cuenta que su monto total por la compra fue de''',monto,''',
y que los descuentos aplicados fueron por''',desc[1],'''%, su factura es
la siguiente:

''',factura)
        
        if monto >= 500 and monto<=1000:
            montoDesc = monto * descOperaciones[2]
            factura = {'Valor a pagar':montoDesc}
            print(f'''
FACTURA DE COMPRA:

Teniendo en cuenta que su monto total por la compra fue de''',monto,''',
y que los descuentos aplicados fueron por''',desc[2],'''%, su factura es
la siguiente:

''',factura)

        if monto >= 1000:
            montoDesc = monto * descOperaciones[3]
            factura = {'Valor a pagar':montoDesc}
            print(f'''
FACTURA DE COMPRA:

Teniendo en cuenta que su monto total por la compra fue de''',monto,''',
y que los descuentos aplicados fueron por''',desc[3],''', su factura es
la siguiente:

''',factura)
    return factura

compra()

        
 