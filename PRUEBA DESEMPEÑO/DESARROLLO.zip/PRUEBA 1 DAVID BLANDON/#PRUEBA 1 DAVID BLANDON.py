#app para administrar tareas. agregar, modificar, eliminar, lista, verificar

tareas = {}
flag = 0
num = (1,2,3)

def menu():
    comandos = ('add','mod','del','lsit','verify')
    while flag == 0:
        what = input(f'''
SISTEMA DE TAREAS:

BIENVENIDO, a nuestro sistema de tareas. A continuación te mostramos los comandos
que podrás usar para realizar cualquier acción.

1. Para agregar una tarea escribir comando 'add'
2. Para modficar una tarea escribir comando 'mod'
3. Para eliminar una tarea escribir comando 'del'
4. Para ver una lista con todas las tareas existentes escribir comando 'list'
4. Para verificar existencia o estado de una tarea escribir comando 'verify'
5. Para salir del sistema escribir 'end'

Escribir que desea hacer:''')
        
        while what not in comandos:
            what = input(f'''
Comando no encontrado. Por favor escribir de nuevo que desea hacer:''')
            
        if what=='add':
            var1 = addTask()
        
        # if what=='mod':
        #     modTask(var1[0],var1[1],var1[2])
            
        if what=='del':
            delTask(var1[0],var1[1],var1[2])
            
        if what=='list':
            listTask(var1[0],var1[1],var1[2])
        
        if what=='verify':
            verifyTask(var1[0],var1[1],var1[2])
            
        if what=='end':
            print('Has salido existosamente de nuestro sistema. Vuelva pronto')
            break
        
        
            
def addTask():
    while flag == 0:
        task = input('TAREA. Escribe el nombre de la tarea que desea agregar:').lower()
        project = input('PROYECTO. Escribe el proyecto al que pertenece la tarea:').lower()
        status = int(input(f'''ESTADOS.
(1) activa
(2) pausada
(3) descartada

Escribe el numero del estado de la tarea'''))
        while status not in num:
            what = input(f'''
Estado no existente. Por favor escribir de nuevo el estado de la tarea:''')
            
        if status==1:
            status='activa'
        if status==2:
            status='pausada'
        if status==3:
            status='descartada'
        
        tareas[task] = [{'Proyecto':project},{'Estado':status}]
        
        ask = input("Si desea agregar una tarea nueva, escribir 'si':").lower()
        if ask != 'si':
            print('Asi ha quedado su lista de tareas:')
            for i in tareas.items():
                print(i)
            break
    return (task,project,status)
        
        
# def modTask(task,project,status):
#     taskMod = input('Escribe el nombre de la tarea que desea modificar:').lower()
    
#     while taskMod not in tareas.keys():
#         taskMod = input(f'''
# Tarea no encontrada. Por favor escribir de nuevo el nombre de la tarea que desea modificar:''').lower()
    
#     for task,valor in tareas.items():        
#         modify = int(input(f'''MODIFICADORES.
# (1) move. CAMBIA EL PROYECTO DE LA TAREA
# (2) status. CAMBIA EL ESTADO DE LA TAREA
# (3) rename. CAMBIA EL NOMBRE DE LA TAREA

# Escribe el numero del modificador a emplear:'''))
        
#         while modify not in num:
#                 what = input(f'''
# Estado no existente. Por favor escribir de nuevo el estado de la tarea:''')
        
#         if modify==1:
#             projectNew = input('Escribe el nuevo nombre del proyecto para la tarea:').lower()
#             tareas[task] = [{'Proyecto':projectNew},{'Estado':status}]
        
#         if modify==2:
#             statusNew = int(input(f'''ESTADOS.
# (1) activa
# (2) pausada
# (3) descartada

# Escribe el nuevo estado de la tarea'''))
#             while statusNew not in num:
#                     statusNew = input(f'''
# Estado no existente. Por favor escribir de nuevo el estado de la tarea:''')
            
#             if statusNew==1:
#                 statusNew='activa'
#             if statusNew==2:
#                 statusNew='pausada'
#             if statusNew==3:
#                 statusNew='descartada'
        
#             tareas[task] = [{'Proyecto':project},{'Estado':statusNew}]
        
#         if modify==3:
#             taskNew = input('Escribe el nuevo nombre del proyecto para la tarea:').lower()
#             if task==taskMod:
#                 task=taskNew
#                 tareas[taskNew] = tareas[task]
#             tareas.pop(task)
        
#         ask = input("Si desea hacer mas modificaciones a la tarea elegida, escribir 'si':").lower()

#         if ask != 'si':
#             print(f'''Asi ha quedado la informacion actualizada de su tarea''',taskMod,''':''',tareas[taskMod])
#             break

def delTask():
    while flag == 0:
        taskDel = input('Escribe el nombre de la tarea que desea eliminar:').lower()
    
        while taskDel not in tareas.keys():
            taskDel = input(f'''
Tarea no encontrada. Por favor escribir de nuevo el nombre de la tarea que desea modificar:''').lower()
    
        tareas.pop(taskDel)
        ask = input("Si desea eliminar una tarea nueva, escribir 'si':").lower()
        if ask != 'si':
            print('Asi ha quedado su lista de tareas:')
            for i in tareas.items():
                print(i)
            break
    return tareas

def listTask():
    print('LISTA DE TAREAS:')
    for i in tareas.items():
        print(i)

    return tareas

def verifyTask(task,project,status):
    for task,valor in tareas.items():
        taskVerify = input('Escribe el nombre de la tarea que desea verificar:').lower()

        while taskVerify not in tareas.keys():
            taskVerify = input(f'''
Tarea no encontrada. Por favor escribir de nuevo el nombre de la tarea que desea modificar:''').lower()
            
        print('Tarea encontrada. A continuacion se muestra su informacion:')
        if task==taskVerify:
            print(f'''TAREA:''',task,'''INFO:''',valor)

    return tareas


            
        

        
        
menu()        
        
    
    
    